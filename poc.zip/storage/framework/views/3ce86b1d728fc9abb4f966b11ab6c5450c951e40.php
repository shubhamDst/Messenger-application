<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h2>Group Name: </h2>
			<p><?php echo e($group->name); ?></p>

			<h3>Group Messages:</h3>

			<form name="addMsg" id="addMsg" method="POST" action="<?php echo e(route('save-msg')); ?>">
                <div class="card">
                    <div class="card-header"></div>
                    
                    <div>
                        <label><b>Message:</b></label>
                        <textarea name="message" required></textarea>
                    </div>
                    <div>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="hidden" name="group_id" value="<?php echo e(Request::segment(2)); ?>">
                        <button type="submit" class="registerbtn">Send</button>
                    </div>
                </div>
            </form>

			<ul>
			    <?php $__currentLoopData = $group->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <li><?php echo e($msg->message); ?></li>
			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\poc\resources\views/display_msg.blade.php ENDPATH**/ ?>