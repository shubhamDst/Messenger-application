<tr>
    <th>Group Name</th>
    <th>Delete</th>
</tr>
<?php $__currentLoopData = $groupList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><a href="group/<?php echo e($group->id); ?>"><?php echo e($group->name); ?></a></td>
    <td><button onclick="confirmation(<?php echo e($group->id); ?>)">Delete</button></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\poc\resources\views/list-groups.blade.php ENDPATH**/ ?>