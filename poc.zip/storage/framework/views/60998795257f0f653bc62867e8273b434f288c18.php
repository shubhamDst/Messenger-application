<h2>Product Name: </h2>
<p><?php echo e($group->name); ?></p>

<h3>Product Belongs to</h3>

<ul>
    <?php $__currentLoopData = $group->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($msg->message); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\xampp\htdocs\poc\resources\views/user/show.blade.php ENDPATH**/ ?>