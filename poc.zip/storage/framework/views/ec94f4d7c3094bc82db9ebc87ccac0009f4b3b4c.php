<h2>User Name: </h2>
<p><?php echo e($user->name); ?></p>

<h3>User Belongs to</h3>

<ul>
    <?php $__currentLoopData = $user->groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($group->name); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\xampp\htdocs\poc\resources\views/user/display.blade.php ENDPATH**/ ?>