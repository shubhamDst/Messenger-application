<?php

return [
    /*
     * Add your user model here
     * If you change the model here also make sure to add the trait Musonza\Groups\Traits\GroupHelpers;
     * to your User Model
     */
    'user_model' => \Musonza\Groups\Models\User::class,
];
