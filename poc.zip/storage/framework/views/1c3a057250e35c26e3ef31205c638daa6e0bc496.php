<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success custom-alert">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <i class="fa fa-check fa-lg" aria-hidden="true"></i> <strong>Success!</strong> <?php echo e($message); ?>

                </div>
            <?php endif; ?>
            <form name="addGroup" id="addGroup" method="POST" action="<?php echo e(route('save-group')); ?>">
                <div class="card">
                    <div class="card-header"></div>
                    <div>
                        <label for="users"><b>Choose a users:</b></label>
                        <select name="user[]" id="user" multiple>
                            <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label for="email"><b>Group Name:</b></label>
                        <input type="text" placeholder="Enter Group" name="group" id="group" required>
                    </div>
                    <div>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <button type="submit" class="registerbtn">Save</button>
                    </div>
                </div>
            </form>

        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <h4>User Groups:</h4>

                    <table border="1" id="tableRow">
                        <tr>
                            <th>Group Name</th>
                            <th>Delete</th>
                        </tr>
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><a href="group/<?php echo e($group->id); ?>"><?php echo e($group->name); ?></a></td>
                            <td><button onclick="confirmation(<?php echo e($group->id); ?>)">Delete</button></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>


                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        var deleteUserFromGroup = "<?php echo e(route('delete-user-from-group')); ?>";
        function confirmation(gid){
            var result = confirm("Are you sure to delete?");
            if(result){
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: deleteUserFromGroup, // point to server-side PHP script 
                    data: {'group_id':gid},
                    type: 'post',
                    // beforeSend:function(){
                    //     $('.ibox-content').addClass('sk-loading');
                    // },
                    success: function(data){
                        $('.ibox-content').removeClass('sk-loading');
                        if(data){
                            $("#tableRow").html(data);
                        }
                        else{
                            console.log('No Data');
                        }
                    }
                });
            }
        }
    </script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\poc\resources\views/home.blade.php ENDPATH**/ ?>